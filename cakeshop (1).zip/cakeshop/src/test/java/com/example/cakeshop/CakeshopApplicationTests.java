package com.example.cakeshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CakeshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
