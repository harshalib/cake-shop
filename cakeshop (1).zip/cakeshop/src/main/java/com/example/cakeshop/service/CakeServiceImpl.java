package com.example.cakeshop.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.cakeshop.model.Cake;
import com.example.cakeshop.repositories.CakeRepository;





@Service
public class CakeServiceImpl implements CakeService {
    private CakeRepository cakeRepo;

    public CakeServiceImpl(CakeRepository cakeRepo){
        super();
        this.cakeRepo = cakeRepo;
    }

    @Override
    public List<Cake> getAllCakes(){
        return cakeRepo.findAll();
    }

    @Override
    public Cake saveCake(Cake cake){
        return cakeRepo.save(cake);
    }

    @Override
    public Cake getCakeById(Long id){
        return cakeRepo.findById(id).get();
    }

    @Override
    public Cake updateCake(Cake cake){
        return cakeRepo.save(cake);
    }

    @Override
    public void deleteCakeById(Long id){
        cakeRepo.deleteById(id);
    }
    
}
