package com.example.cakeshop.controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.cakeshop.model.Cake;
import com.example.cakeshop.service.CakeService;





@Controller
public class CakeController {
    private CakeService cakeService;

    public CakeController(CakeService cakeService){
        super();
        this.cakeService = cakeService;
    }

  

    @GetMapping("/cakes")
    public String listCakes(Model model){
        model.addAttribute("cakes", cakeService.getAllCakes());
        return "cakes";
    }

    @GetMapping("cakes/new")
        public String createCakeForm(Model model){
            Cake cake = new Cake();
            model.addAttribute("cake", cake);
            return "create_cake";
        }

    @PostMapping("/cakes")
    public String saveCake(@ModelAttribute("cake") Cake cake){
        cakeService.saveCake(cake);
        return "redirect:/cakes";
    }

    @GetMapping("/cakes/edit/{id}")
    public String editCakeForm(@PathVariable Long id, Model model) {
        model.addAttribute("cake", cakeService.getCakeById(id));
        return "edit_cake";
    }

    @PostMapping("/cakes/{id}")
    public String updataCake(@PathVariable Long id, @ModelAttribute("cake") Cake cake, Model model){
        //get cakes from by by id
        Cake existingCake = cakeService.getCakeById(id);
        existingCake.setId(id);
        existingCake.setCakeName(cake.getCakeName());
        existingCake.setCakeCategory(cake.getCakeCategory());
        existingCake.setCakeWeight(cake.getCakeWeight());
        existingCake.setPrice(cake.getPrice());

        //save updated cake object
        cakeService.updateCake(existingCake);
        return "redirect:/cakes";
    }

    @GetMapping("/cakes/{id}")
    public String deleteCake(@PathVariable Long id){
        cakeService.deleteCakeById(id);
        return "redirect:/cakes";
    }
}
