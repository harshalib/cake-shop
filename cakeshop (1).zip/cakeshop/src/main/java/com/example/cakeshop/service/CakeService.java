package com.example.cakeshop.service;

import java.util.List;

import com.example.cakeshop.model.Cake;





public interface CakeService {
    List<Cake> getAllCakes();
    Cake saveCake(Cake cake);
    Cake getCakeById(Long id);
    Cake updateCake(Cake cake);
    void deleteCakeById(Long id);
}
