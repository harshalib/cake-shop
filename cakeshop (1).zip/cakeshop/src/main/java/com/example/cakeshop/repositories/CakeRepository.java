package com.example.cakeshop.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.cakeshop.model.Cake;





public interface CakeRepository extends JpaRepository<Cake, Long> {
    
}
