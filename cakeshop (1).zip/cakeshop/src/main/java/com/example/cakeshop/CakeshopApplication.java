package com.example.cakeshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CakeshopApplication {

	public static void main(String[] args) {
		SpringApplication.run(CakeshopApplication.class, args);
	}

}
