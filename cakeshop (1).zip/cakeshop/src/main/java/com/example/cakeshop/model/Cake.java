package com.example.cakeshop.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="cakelist")
public class Cake {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name="CakeName", nullable = false)
    private String cakeName;
    @Column(name="CakeCategory", nullable = false)
    private String cakeCategory;
    @Column(name="CakeWeight", nullable = false)
    private String cakeWeight;
    @Column(name="CakePrice", nullable = false)
    private Integer price;


    public Cake() {
    }

    


    public Cake(Long id, String cakeName, String cakeCategory, String cakeWeight, Integer price) {
        super();
        this.id = id;
        this.cakeName = cakeName;
        this.cakeCategory = cakeCategory;
        this.cakeWeight = cakeWeight;
        this.price = price;
    }


    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCakeName() {
        return this.cakeName;
    }

    public void setCakeName(String cakeName) {
        this.cakeName = cakeName;
    }

    public String getCakeCategory() {
        return this.cakeCategory;
    }

    public void setCakeCategory(String cakeCategory) {
        this.cakeCategory = cakeCategory;
    }

    public String getCakeWeight() {
        return this.cakeWeight;
    }

    public void setCakeWeight(String cakeWeight) {
        this.cakeWeight = cakeWeight;
    }

    public Integer getPrice() {
        return this.price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }
}